<?php

class Page extends \yii\base\Widget
{
    public function run()
    {
        return $this->render('page');
    }
}